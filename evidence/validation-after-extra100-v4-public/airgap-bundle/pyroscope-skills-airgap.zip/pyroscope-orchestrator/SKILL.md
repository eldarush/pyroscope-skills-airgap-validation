---
name: pyroscope-orchestrator
description: Route end-to-end Pyroscope workflows across the image instrumenter and profile analyzer skills. Use when asked to add Pyroscope to repositories, analyze existing Pyroscope data, do both as a coordinated process, emulate GitLab with GitHub private repos, or keep the workflow reliable for weak/airgapped models.
---

# Pyroscope Orchestrator

## Role

Route, sequence, and audit Pyroscope work. Keep this skill thin; do not duplicate the detailed image or profile workflows.

Use:

- `pyroscope-image-instrumenter` for repo branch/Dockerfile/CI/image/PR work.
- `pyroscope-profile-analyzer` for Pyroscope API/profile/source-mapping/optimization work.

## Decision Tree

Image request:

```text
User asks to install/add/instrument Pyroscope in an image or repo.
Run image instrumenter only.
```

Analysis request:

```text
User asks to inspect Pyroscope data, understand CPU/memory waste, or optimize code.
Run profile analyzer only.
```

End-to-end request:

```text
Run image instrumenter first.
Stop after PR/MR unless profile data already exists.
Run analyzer only after Pyroscope has service data for the intended service/version.
Use a separate optimization branch/PR from the image branch.
```

## Weak Model Rules

- Prefer helper scripts over manual reasoning.
- Keep prompts bounded to one repo, one service, one time window, and one profile type.
- Feed the model a generated weak-model packet or summarized hotspot table, not raw Pyroscope JSON, folded stacks, pprof dumps, or full unbounded reports.
- Treat unsupported runtimes as blocker reports, not creative tasks.
- Never ask a weak model to infer secrets, deployment topology, or missing app dependencies.
- Packet generation is deterministic and does not call, install, or run any model.

## Safety Gates

Do not continue if any gate fails:

- no feature branch,
- non-`-pyroscope` image tag,
- likely secret in diff,
- source mapping is ambiguous,
- optimization is not local/mechanical,
- tests cannot run and implementation was requested,
- user expects deployment or merge.

## Helper

Run `scripts/pyroscope_orchestrator.py audit` to confirm dependent skills and scripts are installed.

Run `scripts/pyroscope_orchestrator.py plan --repo <path> --task image|analyze|both --service <name>` to emit a compact route for weak models.

Run `scripts/pyroscope_airgap_bundle.py roundtrip --out-dir <dir>` before export. It creates a zip bundle for `pyroscope-image-instrumenter`, `pyroscope-profile-analyzer`, and `pyroscope-orchestrator`, verifies file hashes, extracts it, and runs the extracted orchestrator audit. Use `create --out <zip>` for the actual transfer artifact and `verify --bundle <zip>` after copying it into the airgapped environment.

Run `scripts/pyroscope_validation_suite.py` after install/import to execute deterministic readiness gates: script syntax, installed helper audit, image smoke, Docker build smoke, packet parser smoke, weak harness smoke, complex profile smoke, high-cardinality profile budget stress, weak-model prompt budget, and packet audit. Add `--local-pyroscope --pyroscope-url http://localhost:4040` to prove folded-profile ingest/query/report/packet round-trip through a real local Pyroscope instance. Add `--live` for a tiny hosted weak/fallback probe or `--live-full` for the full hosted weak-model benchmark when provider quota is available.

Run `scripts/pyroscope_weak_model_packet.py --report <report.md> --repo <path> --task analyze --pretty --output <packet.json>` to create a bounded context packet from an analyzer report. The packet is the weak-model handoff; treat `report_path` as traceability, not as permission to load the full report into a weak-model prompt.

Run `scripts/pyroscope_weak_model_audit.py --report <report.md> --packet <packet.json>` to check that loaded skill text and analyzer output remain small enough for weak-model usage and that packet schema, hotspot counts, unique-source candidates, unsafe surfaces, and likely secrets pass.
Run `scripts/pyroscope_packet_tool_smoke.py` after packet parser edits to verify strict Markdown parsing, percent parsing, unsafe-surface demotion, and failure on malformed hotspot tables.

Run `scripts/pyroscope_weak_model_benchmark.py --required-streak 2 --max-rounds 3 --max-context-tokens 128000` to execute hosted weak-worker validation with deterministic strong-evaluator scoring across simple-to-complex runtime, Dockerfile, CI, and profile-analysis cases. The evaluator requires exact key=value output and strict safety decisions. This never runs local inference.
Use `--suite extra100` to run the separate 100-case extension across Python, .NET, Java, Spark, Flink, Go, mixed CI/PR, Dockerfile, and profile-analysis scenarios. Use `--suite all` only when you intentionally want the base 50 plus the extra 100 cases.
Use `--case-regex <pattern>` for targeted reruns after a full-suite failure. If hosted providers hit usage limits, the benchmark reports `blocked=true` instead of scoring the quota error as model reasoning.
When Codex Spark is quota-blocked, an explicit `--candidate codex:<model>` run, for example `--candidate codex:gpt-5.4-mini`, is only a stronger Codex sanity check. Do not treat it as MiniMax proxy evidence.

Keep generated prompts below 128k estimated tokens; for non-Codex hosted CLIs also keep prompts far below the stricter Windows command-line guard, usually under 20k characters.
For hosted weak-model CLI runs, inject this orchestrator skill only and rely on deterministic helper outputs plus packet/audit gates for the image and analyzer details. Full three-skill injection is valid for 128k context budgets but can exceed command-line transport limits.
